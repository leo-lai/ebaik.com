// import { ImageResize } from './src/ImageResize.js'
// export default ImageResize

import './image-resize.min.js'