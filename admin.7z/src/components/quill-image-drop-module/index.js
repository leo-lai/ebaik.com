import { ImageDrop } from './src/ImageDrop.js'
export default ImageDrop